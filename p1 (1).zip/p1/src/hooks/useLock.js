import { useRef } from "react";

export function useLock() {
  const lock = useRef(false);

  const acquireLock = () => {
    if (lock.current) return false;
    lock.current = true;
    return true;
  };

  const releaseLock = () => {
    lock.current = false;
  };

  return [acquireLock, releaseLock];
}
