import { useState } from "react";
import { useLock } from "../hooks/useLock";

export default function ProductCard({ product }) {
  const [stock, setStock] = useState(product.stock);
  const [loading, setLoading] = useState(false);
  const [acquireLock, releaseLock] = useLock();

  const handleBuy = async () => {
    if (!acquireLock()) {
      alert("Please wait, processing...");
      return;
    }

    setLoading(true);
    try {
      // Simulate API call
      await new Promise(res => setTimeout(res, 1500));

      // Fake stock update
      if (stock > 0) setStock(stock - 1);
      else alert("Out of stock");
    } catch (err) {
      console.error(err);
    } finally {
      releaseLock();
      setLoading(false);
    }
  };

  return (
    <div className="card">
      <h2>{product.name}</h2>
      <p>Stock: {stock}</p>
      <button onClick={handleBuy} disabled={loading || stock <= 0}>
        {loading ? "Processing..." : "Buy"}
      </button>
    </div>
  );
}
