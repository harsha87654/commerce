import ProductCard from "../components/ProductCard";

export default function Home() {
  const dummyProduct = {
    id: 1,
    name: "Cool Shoes",
    stock: 5,
  };

  return (
    <div>
      <h1>Shop</h1>
      <ProductCard product={dummyProduct} />
    </div>
  );
}
